import javax.swing.JFrame;

public class GameViewer {
    /**
     * @param args
     */
    public static void main(String[] args) {
        JFrame newGame = new MenuFrame();
    }
}
